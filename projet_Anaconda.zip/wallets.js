'use strict';
/**
 * ANACONDA API — Routes : Portefeuilles
 * GET  /api/wallets
 * GET  /api/wallets/:id
 * POST /api/wallets
 * DELETE /api/wallets/:id
 * GET  /api/wallets/:id/balance
 * GET  /api/wallets/:id/plafond
 * POST /api/wallets/verify-phone
 */

const { ok, created, err, notFound, readBody, parseQuery } = require('../utils/http');
const { uid } = require('../db/database');

async function walletRoutes(req, res, db, gateway, auth) {
  const method  = req.method;
  const path    = req.parsedPath;
  const pathParts = path.split('/').filter(Boolean); // ['api','wallets',...]

  /* ── Toutes les routes wallets nécessitent auth ─────────────── */
  return new Promise(resolve => {
    auth(req, res, async () => {
      const userId = req.user.id;

      /* GET /api/wallets ─────────────────────────────────────── */
      if (method === 'GET' && path === '/api/wallets') {
        const wallets = db.userWallets(userId).map(w => ({
          ...w,
          operatorInfo: gateway.getOperator(w.operator),
        }));
        const total = wallets.reduce((s,w)=>s+w.balance, 0);
        return resolve(ok(res, { wallets, totalBalance: total, count: wallets.length }));
      }

      /* POST /api/wallets ────────────────────────────────────── */
      if (method === 'POST' && path === '/api/wallets') {
        const body = await readBody(req);
        const { operator, phone, label } = body;

        if (!operator || !phone)      return resolve(err(res, 'Champs requis : operator, phone'));
        const supportedOps = ['mtn','orange','moov','wave'];
        if (!supportedOps.includes(operator)) return resolve(err(res, `Opérateur non supporté. Valeurs : ${supportedOps.join(', ')}`));
        if (db.findWalletByOp(userId, operator)) return resolve(err(res, `Portefeuille ${operator.toUpperCase()} déjà lié`, 409, 'WALLET_EXISTS'));

        // Vérification réseau
        const verify = await gateway.verifyPhone(operator, phone);
        if (!verify.valid) return resolve(err(res, verify.message, 400, 'INVALID_PHONE'));

        const wallet = db.createWallet({ userId, operator, phone: verify.phone, label: label || verify.network });
        return resolve(created(res, { wallet, message: `Compte ${verify.network} lié avec succès` }));
      }

      /* POST /api/wallets/verify-phone ────────────────────────── */
      if (method === 'POST' && path === '/api/wallets/verify-phone') {
        const body = await readBody(req);
        const { operator, phone } = body;
        if (!operator || !phone) return resolve(err(res, 'Champs requis : operator, phone'));
        const result = await gateway.verifyPhone(operator, phone);
        return resolve(ok(res, result));
      }

      /* Routes avec :id ─────────────────────────────────────── */
      if (pathParts.length >= 3 && pathParts[1] === 'wallets') {
        const walletId = pathParts[2];
        const wallet   = db.findWallet(walletId);
        if (!wallet || wallet.userId !== userId) return resolve(notFound(res));

        /* GET /api/wallets/:id ─────────────────────────────── */
        if (method === 'GET' && pathParts.length === 3) {
          return resolve(ok(res, { ...wallet, operatorInfo: gateway.getOperator(wallet.operator) }));
        }

        /* DELETE /api/wallets/:id ──────────────────────────── */
        if (method === 'DELETE' && pathParts.length === 3) {
          const others = db.userWallets(userId).filter(w => w.id !== walletId);
          if (others.length === 0) return resolve(err(res, 'Impossible de supprimer le dernier portefeuille'));
          db.updateWallet(walletId, { status: 'removed', removedAt: new Date().toISOString() });
          return resolve(ok(res, { message: 'Portefeuille supprimé' }));
        }

        /* GET /api/wallets/:id/balance ─────────────────────── */
        if (method === 'GET' && pathParts[3] === 'balance') {
          const netCheck = await gateway.checkBalance(wallet.operator, wallet.phone);
          return resolve(ok(res, {
            walletId:    wallet.id,
            operator:    wallet.operator,
            phone:       wallet.phone,
            balance:     wallet.balance,
            currency:    'XOF',
            networkOk:   netCheck.available,
            checkedAt:   netCheck.checkedAt,
          }));
        }

        /* GET /api/wallets/:id/plafond ─────────────────────── */
        if (method === 'GET' && pathParts[3] === 'plafond') {
          const op = gateway.getOperator(wallet.operator);
          return resolve(ok(res, {
            walletId:     wallet.id,
            operator:     wallet.operator,
            monthlyUsed:  wallet.monthlyUsed || 0,
            monthlyLimit: op.maxAmount * 12, // limite annuelle
            dailyLimit:   op.maxAmount,
            singleLimit:  op.maxAmount,
            remaining:    Math.max(0, op.maxAmount - (wallet.monthlyUsed || 0)),
            resetDate:    new Date(new Date().getFullYear(), new Date().getMonth()+1, 1).toISOString(),
          }));
        }
      }

      resolve(null);
    });
  });
}

module.exports = walletRoutes;
