'use strict';
/**
 * ANACONDA API — Routes : Opérateurs (publiques)
 * GET /api/operators                    → Liste des opérateurs
 * GET /api/operators/:code              → Détail d'un opérateur
 * GET /api/operators/:code/fee?amount=  → Calculer les frais
 * POST /api/operators/:code/verify      → Vérifier un numéro
 */

const { ok, err, notFound, readBody, parseQuery } = require('../utils/http');

async function operatorRoutes(req, res, db, gateway) {
  const method    = req.method;
  const path      = req.parsedPath;
  const pathParts = path.split('/').filter(Boolean);

  /* GET /api/operators ──────────────────────────────────────────── */
  if (method === 'GET' && path === '/api/operators') {
    return ok(res, { operators: gateway.getAllOperators() });
  }

  /* Routes avec :code ───────────────────────────────────────────── */
  if (pathParts.length >= 3 && pathParts[1] === 'operators') {
    const code = pathParts[2].toLowerCase();

    let op;
    try { op = gateway.getOperator(code); }
    catch { return notFound(res); }

    /* GET /api/operators/:code ──────────────────────────────── */
    if (method === 'GET' && pathParts.length === 3) {
      return ok(res, op);
    }

    /* GET /api/operators/:code/fee?amount=&toOperator= ──────── */
    if (method === 'GET' && pathParts[3] === 'fee') {
      const q  = parseQuery(req);
      const to = q.toOperator;
      const am = parseFloat(q.amount);
      if (!to || isNaN(am)) return err(res, 'Paramètres requis : toOperator, amount');
      try {
        const { fee, feeRate, freeReason } = gateway.computeFee(code, to, am);
        return ok(res, { fromOperator: code, toOperator: to, amount: am, fee, feeRate, freeReason, totalDebit: am + fee, amountCredit: am });
      } catch (e) { return err(res, e.message); }
    }

    /* POST /api/operators/:code/verify ──────────────────────── */
    if (method === 'POST' && pathParts[3] === 'verify') {
      const body = await readBody(req);
      const { phone } = body;
      if (!phone) return err(res, 'Champ requis : phone');
      const result = await gateway.verifyPhone(code, phone);
      return ok(res, result);
    }
  }

  return null;
}

module.exports = operatorRoutes;
