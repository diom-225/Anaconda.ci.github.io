'use strict';
/**
 * ANACONDA API — Middleware d'authentification
 */

const { verifyToken }  = require('../utils/jwt');
const { unauthorized } = require('../utils/http');

function authMiddleware(db) {
  return function (req, res, next) {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;

    if (!token) return unauthorized(res);

    const payload = verifyToken(token);
    if (!payload)  return unauthorized(res);

    const session = db.findSession(token);
    if (!session)  return unauthorized(res);

    const user = db.findUser(payload.userId);
    if (!user)     return unauthorized(res);

    req.user  = user;
    req.token = token;
    next();
  };
}

module.exports = authMiddleware;
