'use strict';
/**
 * ANACONDA API — Utilitaires HTTP
 */

/* ── Réponses standardisées ────────────────────────────────────────── */
function ok(res, data, statusCode = 200) {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: true, data, timestamp: new Date().toISOString() }));
}

function created(res, data) { ok(res, data, 201); }

function err(res, message, statusCode = 400, code = 'ERROR') {
  res.writeHead(statusCode, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ success: false, error: { code, message }, timestamp: new Date().toISOString() }));
}

function notFound(res)  { err(res, 'Ressource introuvable', 404, 'NOT_FOUND'); }
function unauthorized(res) { err(res, 'Non autorisé — authentifiez-vous', 401, 'UNAUTHORIZED'); }
function forbidden(res)    { err(res, 'Accès interdit', 403, 'FORBIDDEN'); }
function serverError(res, msg = 'Erreur interne du serveur') { err(res, msg, 500, 'INTERNAL_ERROR'); }

/* ── Lecture du body JSON ──────────────────────────────────────────── */
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 1e6) req.destroy(); });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('JSON invalide')); }
    });
    req.on('error', reject);
  });
}

/* ── Parse URL params ──────────────────────────────────────────────── */
function parseQuery(req) {
  const url = new URL(req.url, 'http://localhost');
  const params = {};
  url.searchParams.forEach((v, k) => { params[k] = v; });
  return params;
}

module.exports = { ok, created, err, notFound, unauthorized, forbidden, serverError, readBody, parseQuery };
