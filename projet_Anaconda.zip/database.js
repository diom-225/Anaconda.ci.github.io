'use strict';
/**
 * ANACONDA API — Couche de données
 * Base de données JSON persistante (remplace SQLite/Postgres pour portabilité)
 * En production : remplacer par PostgreSQL + Prisma
 */

const fs   = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_FILE = path.join(__dirname, 'anaconda.json');

/* ── Schéma initial ───────────────────────────────────────────────── */
const INITIAL_DB = {
  users: [
    {
      id:        'usr-001',
      name:      'Kofi Asante',
      email:     'kofi@anaconda.ci',
      phone:     '0712345656',
      pinHash:   hashPin('1234'),
      kycStatus: 'verified',
      createdAt: new Date().toISOString(),
      devices: [
        { id:'dev-001', name:'iPhone 14 Pro',      os:'iOS 17.4',   location:'Abidjan, CI',  current:true,  addedAt: new Date().toISOString() },
        { id:'dev-002', name:'Samsung Galaxy A54', os:'Android 14', location:'Bouaké, CI',   current:false, addedAt: new Date(Date.now()-5*86400000).toISOString() }
      ]
    }
  ],
  wallets: [
    { id:'wal-mtn-001',    userId:'usr-001', operator:'mtn',    phone:'0712345656', balance:89500,  monthlyIn:350000, monthlyOut:260500, monthlyUsed:1420000, limit:2000000, status:'active', linkedAt: new Date().toISOString() },
    { id:'wal-orange-001', userId:'usr-001', operator:'orange', phone:'0598765454', balance:42350,  monthlyIn:120000, monthlyOut:77650,  monthlyUsed:680000,  limit:2000000, status:'active', linkedAt: new Date().toISOString() },
    { id:'wal-moov-001',   userId:'usr-001', operator:'moov',   phone:'0155443333', balance:31000,  monthlyIn:80000,  monthlyOut:49000,  monthlyUsed:180000,  limit:1000000, status:'active', linkedAt: new Date().toISOString() },
    { id:'wal-wave-001',   userId:'usr-001', operator:'wave',   phone:'0700112222', balance:85000,  monthlyIn:500000, monthlyOut:415000, monthlyUsed:440000,  limit:2000000, status:'active', linkedAt: new Date().toISOString() }
  ],
  transactions: [
    { id:'txn-001', userId:'usr-001', type:'credit', operator:'wave',   amount:85000,  fee:0,   status:'completed', ref:'ANA20380145', label:'Dépôt Wave',            counterparty:'Salaire Entreprise XYZ', createdAt: new Date(Date.now()-7200000).toISOString()   },
    { id:'txn-002', userId:'usr-001', type:'debit',  operator:'wave',   toOperator:'orange', amount:25000, fee:250, status:'completed', ref:'ANA20380089', label:'Transfert Wave→Orange', createdAt: new Date(Date.now()-18000000).toISOString()  },
    { id:'txn-003', userId:'usr-001', type:'credit', operator:'mtn',    amount:50000,  fee:0,   status:'completed', ref:'ANA20380012', label:'Virement reçu MTN',      counterparty:'Adjoa Brou',            createdAt: new Date(Date.now()-25200000).toISOString()  },
    { id:'txn-004', userId:'usr-001', type:'debit',  operator:'orange', toOperator:'moov', amount:10000, fee:150, status:'completed', ref:'ANA20379901', label:'Paiement Orange→Moov',  createdAt: new Date(Date.now()-86400000).toISOString()   },
    { id:'txn-005', userId:'usr-001', type:'credit', operator:'mtn',    amount:15000,  fee:0,   status:'completed', ref:'ANA20379844', label:'Dépôt MTN MoMo',         counterparty:'Jean-Paul Diarra',      createdAt: new Date(Date.now()-100800000).toISOString() },
    { id:'txn-006', userId:'usr-001', type:'debit',  operator:'moov',   toOperator:'mtn', amount:5000, fee:50, status:'completed', ref:'ANA20379801', label:'Retrait Moov→MTN',       createdAt: new Date(Date.now()-115200000).toISOString() },
    { id:'txn-007', userId:'usr-001', type:'credit', operator:'wave',   amount:450000, fee:0,   status:'completed', ref:'ANA20379600', label:'Salaire Wave',            counterparty:'Entreprise XYZ',        createdAt: new Date(Date.now()-172800000).toISOString() },
    { id:'txn-008', userId:'usr-001', type:'debit',  operator:'wave',   toOperator:'mtn', amount:120000, fee:0, status:'completed', ref:'ANA20379622', label:'Transfert Wave→MTN',     createdAt: new Date(Date.now()-180000000).toISOString() },
    { id:'txn-009', userId:'usr-001', type:'debit',  operator:'orange', toOperator:'moov', amount:8000, fee:120, status:'pending', ref:'ANA20379688', label:'Transfert Orange→Moov',  createdAt: new Date(Date.now()-190000000).toISOString() }
  ],
  sessions: [],
  otps: []
};

/* ── Utilitaires ──────────────────────────────────────────────────── */
function hashPin(pin) {
  return crypto.createHash('sha256').update('anaconda_salt_' + pin).digest('hex');
}

function uid(prefix = 'id') {
  return prefix + '-' + Date.now().toString(36) + crypto.randomBytes(3).toString('hex');
}

/* ── Chargement / Sauvegarde ─────────────────────────────────────── */
function load() {
  try {
    if (fs.existsSync(DB_FILE)) {
      return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    }
  } catch (e) { console.error('[DB] Load error:', e.message); }
  const db = JSON.parse(JSON.stringify(INITIAL_DB));
  save(db);
  return db;
}

function save(db) {
  try { fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2)); }
  catch (e) { console.error('[DB] Save error:', e.message); }
}

/* ── API CRUD ─────────────────────────────────────────────────────── */
class Database {
  constructor() { this._db = load(); }

  // Rechargement depuis disque
  reload() { this._db = load(); }

  /* USERS */
  findUser(id)        { return this._db.users.find(u => u.id === id) || null; }
  findUserByPhone(ph) { return this._db.users.find(u => u.phone === ph) || null; }

  createUser(data) {
    const user = { id: uid('usr'), createdAt: new Date().toISOString(), devices: [], kycStatus: 'pending', ...data };
    this._db.users.push(user);
    save(this._db);
    return user;
  }

  updateUser(id, patch) {
    const i = this._db.users.findIndex(u => u.id === id);
    if (i === -1) return null;
    this._db.users[i] = { ...this._db.users[i], ...patch };
    save(this._db);
    return this._db.users[i];
  }

  /* WALLETS */
  userWallets(userId) { return this._db.wallets.filter(w => w.userId === userId && w.status === 'active'); }
  findWallet(id)      { return this._db.wallets.find(w => w.id === id) || null; }
  findWalletByOp(userId, operator) { return this._db.wallets.find(w => w.userId === userId && w.operator === operator && w.status !== 'removed') || null; }

  createWallet(data) {
    const w = { id: uid('wal'), linkedAt: new Date().toISOString(), status: 'active', balance: 0, monthlyIn: 0, monthlyOut: 0, monthlyUsed: 0, ...data };
    this._db.wallets.push(w);
    save(this._db);
    return w;
  }

  updateWallet(id, patch) {
    const i = this._db.wallets.findIndex(w => w.id === id);
    if (i === -1) return null;
    this._db.wallets[i] = { ...this._db.wallets[i], ...patch };
    save(this._db);
    return this._db.wallets[i];
  }

  /* TRANSACTIONS */
  userTransactions(userId, { type, operator, limit = 50, offset = 0 } = {}) {
    let txs = this._db.transactions.filter(t => t.userId === userId);
    if (type)     txs = txs.filter(t => t.type === type);
    if (operator) txs = txs.filter(t => t.operator === operator || t.toOperator === operator);
    txs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return { total: txs.length, data: txs.slice(offset, offset + limit) };
  }

  findTx(id)    { return this._db.transactions.find(t => t.id === id) || null; }
  findTxByRef(ref) { return this._db.transactions.find(t => t.ref === ref) || null; }

  createTx(data) {
    const tx = { id: uid('txn'), createdAt: new Date().toISOString(), status: 'pending', ...data };
    this._db.transactions.push(tx);
    save(this._db);
    return tx;
  }

  updateTx(id, patch) {
    const i = this._db.transactions.findIndex(t => t.id === id);
    if (i === -1) return null;
    this._db.transactions[i] = { ...this._db.transactions[i], ...patch };
    save(this._db);
    return this._db.transactions[i];
  }

  /* SESSIONS */
  createSession(userId, token, expiresAt) {
    this._db.sessions = this._db.sessions.filter(s => s.userId !== userId); // 1 session active
    const s = { id: uid('ses'), userId, token, expiresAt, createdAt: new Date().toISOString() };
    this._db.sessions.push(s);
    save(this._db);
    return s;
  }

  findSession(token) {
    return this._db.sessions.find(s => s.token === token && new Date(s.expiresAt) > new Date()) || null;
  }

  deleteSession(token) {
    this._db.sessions = this._db.sessions.filter(s => s.token !== token);
    save(this._db);
  }

  /* OTP */
  createOTP(phone, code) {
    this._db.otps = this._db.otps.filter(o => o.phone !== phone);
    const o = { phone, code, expiresAt: new Date(Date.now() + 5 * 60000).toISOString() };
    this._db.otps.push(o);
    save(this._db);
    return o;
  }

  verifyOTP(phone, code) {
    const o = this._db.otps.find(o => o.phone === phone && o.code === code && new Date(o.expiresAt) > new Date());
    if (o) { this._db.otps = this._db.otps.filter(x => x.phone !== phone); save(this._db); }
    return !!o;
  }

  /* STATS */
  userStats(userId) {
    const txs  = this._db.transactions.filter(t => t.userId === userId);
    const now  = new Date();
    const m    = txs.filter(t => { const d = new Date(t.createdAt); return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear(); });
    const wals = this.userWallets(userId);
    return {
      totalBalance:   wals.reduce((s,w)=>s+w.balance, 0),
      monthlyTxCount: m.length,
      monthlyFees:    m.reduce((s,t)=>s+(t.fee||0), 0),
      monthlyIn:      m.filter(t=>t.type==='credit').reduce((s,t)=>s+t.amount, 0),
      monthlyOut:     m.filter(t=>t.type==='debit').reduce((s,t)=>s+t.amount, 0),
      walletCount:    wals.length,
    };
  }
}

module.exports = { Database, hashPin, uid };
