'use strict';
/**
 * ANACONDA API — Authentification
 * JWT simulé avec HMAC-SHA256 (sans librairie externe)
 */

const crypto = require('crypto');

const SECRET  = process.env.JWT_SECRET || 'anaconda_secret_key_2026_ci';
const EXPIRES = 24 * 60 * 60 * 1000; // 24h

function base64url(buf) {
  return buf.toString('base64').replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');
}

function signToken(payload) {
  const header  = base64url(Buffer.from(JSON.stringify({ alg:'HS256', typ:'JWT' })));
  const body    = base64url(Buffer.from(JSON.stringify({ ...payload, iat: Date.now(), exp: Date.now() + EXPIRES })));
  const sig     = base64url(crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest());
  return `${header}.${body}.${sig}`;
}

function verifyToken(token) {
  try {
    const [header, body, sig] = token.split('.');
    const expected = base64url(crypto.createHmac('sha256', SECRET).update(`${header}.${body}`).digest());
    if (sig !== expected) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64').toString());
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}

module.exports = { signToken, verifyToken, EXPIRES };
