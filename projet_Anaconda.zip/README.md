# 🐍 ANACONDA API — Documentation complète

> API REST Node.js pure · Transferts Mobile Money · MTN · Orange · Moov · Wave

---

## 🚀 Démarrage rapide

```bash
# Lancer le serveur (aucune dépendance à installer)
node server.js

# Le serveur démarre sur http://localhost:3000
# Compte démo : phone=0712345656 · PIN=1234
```

---

## 🏗️ Architecture

```
anaconda-api/
├── server.js                  ← Point d'entrée principal
├── db/
│   ├── database.js            ← Couche données (JSON persistant)
│   └── anaconda.json          ← Base de données (auto-générée)
├── services/
│   └── operatorGateway.js     ← Passerelle MTN / Orange / Moov / Wave
├── middleware/
│   └── auth.js                ← Vérification JWT sur routes protégées
├── routes/
│   ├── auth.js                ← Authentification & PIN
│   ├── wallets.js             ← Portefeuilles
│   ├── transfers.js           ← Transferts
│   ├── users.js               ← Profil & appareils
│   └── operators.js           ← Info opérateurs (public)
└── utils/
    ├── jwt.js                 ← Tokens HMAC-SHA256
    └── http.js                ← Helpers réponses JSON
```

---

## 🔐 Authentification

Toutes les routes `[auth]` nécessitent un header :
```
Authorization: Bearer <token>
```

Le token est obtenu via `POST /api/auth/login`.

---

## 📖 Endpoints

### AUTH
| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/auth/register` | Créer un compte |
| POST | `/api/auth/login` | Se connecter |
| POST | `/api/auth/logout` | Se déconnecter `[auth]` |
| POST | `/api/auth/otp/send` | Envoyer OTP SMS |
| POST | `/api/auth/otp/verify` | Vérifier OTP |
| POST | `/api/auth/pin/change` | Changer le PIN `[auth]` |

### UTILISATEUR
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/user/profile` | Profil `[auth]` |
| PATCH | `/api/user/profile` | Modifier profil `[auth]` |
| GET | `/api/user/stats` | Stats du mois `[auth]` |
| GET | `/api/user/devices` | Appareils connectés `[auth]` |
| DELETE | `/api/user/devices/:id` | Retirer appareil `[auth]` |
| DELETE | `/api/user/devices` | Déconnecter tous `[auth]` |
| POST | `/api/user/phone/change` | Changer numéro `[auth]` |

### PORTEFEUILLES
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/wallets` | Lister mes portefeuilles `[auth]` |
| POST | `/api/wallets` | Ajouter un portefeuille `[auth]` |
| GET | `/api/wallets/:id` | Détail `[auth]` |
| DELETE | `/api/wallets/:id` | Supprimer `[auth]` |
| GET | `/api/wallets/:id/balance` | Solde réseau `[auth]` |
| GET | `/api/wallets/:id/plafond` | Plafonds `[auth]` |
| POST | `/api/wallets/verify-phone` | Vérifier numéro `[auth]` |

### TRANSFERTS
| Méthode | Route | Description |
|---------|-------|-------------|
| POST | `/api/transfers/quote` | Simuler (frais) `[auth]` |
| POST | `/api/transfers` | Exécuter `[auth]` |
| GET | `/api/transfers` | Historique `[auth]` |
| GET | `/api/transfers/:id` | Détail `[auth]` |
| GET | `/api/transfers/:id/status` | Statut temps réel `[auth]` |

### OPÉRATEURS (public)
| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/operators` | Liste des opérateurs |
| GET | `/api/operators/:code` | Détail opérateur |
| GET | `/api/operators/:code/fee?amount=&toOperator=` | Calculer frais |
| POST | `/api/operators/:code/verify` | Vérifier numéro |

---

## 💡 Exemples

### Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"0712345656","pin":"1234"}'
```

### Mes portefeuilles
```bash
curl http://localhost:3000/api/wallets \
  -H "Authorization: Bearer <token>"
```

### Simuler un transfert
```bash
curl -X POST http://localhost:3000/api/transfers/quote \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"fromOperator":"mtn","toOperator":"orange","amount":10000}'
```

### Exécuter un transfert
```bash
curl -X POST http://localhost:3000/api/transfers \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{"fromOperator":"mtn","toOperator":"wave","amount":5000,"pin":"1234"}'
```

---

## 📊 Grille des frais

| De \ Vers | MTN | Orange | Moov | Wave |
|-----------|-----|--------|------|------|
| **MTN**   | —   | 1%     | 1.5% | **0%** ★ |
| **Orange**| 1%  | —      | 1.5% | 1%   |
| **Moov**  | 1%  | 1%     | —    | 1%   |
| **Wave**  | **0%** ★ | 1% | 1% | —  |

★ Partenariat MTN-Wave : transferts gratuits et instantanés

---

## 🔌 Intégration production

Pour connecter une vraie API opérateur, modifiez `services/operatorGateway.js` :

```javascript
// Remplacer simulateOperatorResponse() par des vrais appels HTTP :

// MTN MoMo :
// https://sandbox.momodeveloper.mtn.com/collection/v1

// Orange Money :
// https://api.orange.com/orange-money-webpay/dev/v1

// Moov Money :
// https://api.moov-africa.ci/v2

// Wave :
// https://api.wave.com/v1
```

---

## 🛡️ Sécurité

- PIN haché en SHA-256 + sel avant stockage
- Tokens JWT signés HMAC-SHA256 (expiration 24h)
- Une seule session active par utilisateur
- Validation de chaque champ entrant
- Vérification réseau des numéros de téléphone
- Logs de toutes les requêtes avec timestamp

---

*ANACONDA API v2.1.0 · Côte d'Ivoire · 2026*
