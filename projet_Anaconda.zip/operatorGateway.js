'use strict';
/**
 * ANACONDA API — Passerelle Opérateurs
 *
 * Simule les API des réseaux mobiles africains :
 *   - MTN Mobile Money (CI)
 *   - Orange Money (CI)
 *   - Moov Money (CI)
 *   - Wave (CI)
 *
 * En production : remplacer chaque méthode par l'appel HTTP réel
 * vers l'API de chaque opérateur (OAuth2 / REST / SOAP selon l'opérateur).
 */

const crypto = require('crypto');

/* ── Config opérateurs ─────────────────────────────────────────────── */
const OPERATORS = {
  mtn: {
    name:      'MTN Mobile Money',
    code:      'MTN_CI',
    currency:  'XOF',
    feeRate:   0,          // 0% sur transferts internes Anaconda
    feeFixed:  0,
    minAmount: 100,
    maxAmount: 2000000,
    daily:     5000000,
    delay:     0,          // ms (0 = instantané)
    // Endpoints réels (exemple) :
    // baseUrl: 'https://sandbox.momodeveloper.mtn.com/collection/v1',
    // authUrl: 'https://sandbox.momodeveloper.mtn.com/collection/token/',
    prefixes:  ['07','08','09'],
  },
  orange: {
    name:      'Orange Money',
    code:      'OM_CI',
    currency:  'XOF',
    feeRate:   0.01,
    feeFixed:  0,
    minAmount: 100,
    maxAmount: 2000000,
    daily:     3000000,
    delay:     2000,
    // baseUrl: 'https://api.orange.com/orange-money-webpay/dev/v1',
    prefixes:  ['05','06'],
  },
  moov: {
    name:      'Moov Money',
    code:      'MOOV_CI',
    currency:  'XOF',
    feeRate:   0.015,
    feeFixed:  0,
    minAmount: 100,
    maxAmount: 1000000,
    daily:     2000000,
    delay:     5000,
    // baseUrl: 'https://api.moov-africa.ci/v2',
    prefixes:  ['01','02'],
  },
  wave: {
    name:      'Wave',
    code:      'WAVE_CI',
    currency:  'XOF',
    feeRate:   0,
    feeFixed:  0,
    minAmount: 1,
    maxAmount: 2000000,
    daily:     10000000,
    delay:     0,
    // baseUrl: 'https://api.wave.com/v1',
    prefixes:  ['07','01'],
  }
};

/* ── Délai simulé ──────────────────────────────────────────────────── */
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/* ── Génération de référence ───────────────────────────────────────── */
function genRef(opCode) {
  return `ANA-${opCode}-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

/* ── Simulation réponse opérateur ──────────────────────────────────── */
function simulateOperatorResponse(operator, action, amount) {
  const op = OPERATORS[operator];
  // Simule un taux d'échec réaliste (2% d'erreurs réseau)
  if (Math.random() < 0.02) {
    return { success: false, code: 'NETWORK_TIMEOUT', message: `${op.name} : timeout réseau` };
  }
  return {
    success:         true,
    operatorRef:     genRef(op.code),
    operatorName:    op.name,
    operatorCode:    op.code,
    action,
    amount,
    currency:        op.currency,
    processedAt:     new Date().toISOString(),
    networkLatencyMs: Math.floor(Math.random() * 300) + 50,
  };
}

/* ══════════════════════════════════════════════════════════════════════
   CLASSE PRINCIPALE : OperatorGateway
══════════════════════════════════════════════════════════════════════ */
class OperatorGateway {

  /* ── Obtenir la config d'un opérateur ─────────────────────────── */
  getOperator(code) {
    const op = OPERATORS[code];
    if (!op) throw new Error(`Opérateur inconnu : ${code}`);
    return { code, ...op };
  }

  getAllOperators() {
    return Object.entries(OPERATORS).map(([code, op]) => ({
      code,
      name:      op.name,
      currency:  op.currency,
      feeRate:   op.feeRate,
      feeFixed:  op.feeFixed,
      minAmount: op.minAmount,
      maxAmount: op.maxAmount,
      delay:     op.delay,
      prefixes:  op.prefixes,
    }));
  }

  /* ── Calcul des frais ─────────────────────────────────────────── */
  computeFee(fromOp, toOp, amount) {
    // MTN ↔ Wave = toujours gratuit (accord partenariat)
    if ((fromOp==='mtn'&&toOp==='wave')||(fromOp==='wave'&&toOp==='mtn')) {
      return { fee: 0, feeRate: 0, freeReason: 'Partenariat MTN-Wave' };
    }
    const op    = OPERATORS[toOp];
    const fee   = Math.round(amount * op.feeRate) + op.feeFixed;
    return { fee, feeRate: op.feeRate, freeReason: null };
  }

  /* ── Vérification d'un numéro ─────────────────────────────────── */
  async verifyPhone(operator, phone) {
    await sleep(200);
    const op      = OPERATORS[operator];
    const cleaned = phone.replace(/\s/g,'').replace(/^\+225/,'');
    const prefix  = cleaned.slice(0,2);
    const valid   = op.prefixes.includes(prefix) && cleaned.length === 10;
    return {
      valid,
      operator,
      phone:    '+225 ' + cleaned,
      network:  op.name,
      message:  valid ? 'Numéro vérifié' : `Préfixe ${prefix} non attribué à ${op.name}`,
    };
  }

  /* ── Vérification du solde (réseau) ───────────────────────────── */
  async checkBalance(operator, phone) {
    await sleep(300);
    const result = simulateOperatorResponse(operator, 'balance_check', 0);
    if (!result.success) throw new Error(result.message);
    return {
      operator,
      phone,
      network:   OPERATORS[operator].name,
      available: true,
      checkedAt: new Date().toISOString(),
    };
  }

  /* ── Débit (retrait côté source) ──────────────────────────────── */
  async debit(operator, phone, amount, ref) {
    const op = OPERATORS[operator];
    if (amount < op.minAmount) throw new Error(`Montant minimum : ${op.minAmount} FCFA`);
    if (amount > op.maxAmount) throw new Error(`Montant maximum : ${op.maxAmount} FCFA`);

    await sleep(op.delay / 2);

    const result = simulateOperatorResponse(operator, 'debit', amount);
    if (!result.success) throw new Error(result.message);

    return {
      ...result,
      ref,
      phone,
      amount,
      operator,
      step: 'debit',
    };
  }

  /* ── Crédit (dépôt côté destination) ─────────────────────────── */
  async credit(operator, phone, amount, ref) {
    await sleep(OPERATORS[operator].delay / 2);

    const result = simulateOperatorResponse(operator, 'credit', amount);
    if (!result.success) throw new Error(result.message);

    return {
      ...result,
      ref,
      phone,
      amount,
      operator,
      step: 'credit',
    };
  }

  /* ── Transfert complet (débit → crédit) ───────────────────────── */
  async transfer({ fromOperator, fromPhone, toOperator, toPhone, amount, ref }) {
    const { fee }   = this.computeFee(fromOperator, toOperator, amount);
    const totalDebit = amount + fee;

    // Étape 1 : débit source
    const debitResult = await this.debit(fromOperator, fromPhone, totalDebit, ref + '-D');

    // Étape 2 : crédit destination
    let creditResult;
    try {
      creditResult = await this.credit(toOperator, toPhone, amount, ref + '-C');
    } catch (e) {
      // En production : déclencher un remboursement automatique
      return {
        success:        false,
        ref,
        error:          'Crédit échoué — remboursement initié',
        debitRef:       debitResult.operatorRef,
        rollbackNeeded: true,
      };
    }

    return {
      success:          true,
      ref,
      fromOperator,
      toOperator,
      amount,
      fee,
      totalDebit,
      debitRef:         debitResult.operatorRef,
      creditRef:        creditResult.operatorRef,
      processedAt:      new Date().toISOString(),
      networkLatencyMs: debitResult.networkLatencyMs + creditResult.networkLatencyMs,
    };
  }

  /* ── Envoi OTP SMS (simulé) ───────────────────────────────────── */
  async sendOTP(phone) {
    await sleep(500);
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    console.log(`[OTP DEMO] Code pour ${phone} : ${code}`);
    return { sent: true, phone, expiresIn: 300, code }; // en prod, ne pas retourner le code !
  }
}

module.exports = { OperatorGateway, OPERATORS };
