'use strict';
/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║            ANACONDA API — Serveur Principal                     ║
 * ║    Transferts Mobile Money : MTN · Orange · Moov · Wave         ║
 * ║    Version 2.1.0 · Côte d'Ivoire · Node.js natif               ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * Démarrage : node server.js
 * Port par défaut : 3000
 */

const http = require('http');
const { Database }        = require('./db/database');
const { OperatorGateway } = require('./services/operatorGateway');
const authMiddleware      = require('./middleware/auth');

const authRoutes      = require('./routes/auth');
const walletRoutes    = require('./routes/wallets');
const transferRoutes  = require('./routes/transfers');
const userRoutes      = require('./routes/users');
const operatorRoutes  = require('./routes/operators');

const { notFound, serverError } = require('./utils/http');

const PORT = process.env.PORT || 3000;

/* ── Instances partagées ─────────────────────────────────────────── */
const db      = new Database();
const gateway = new OperatorGateway();
const auth    = authMiddleware(db);

/* ── CORS Headers ────────────────────────────────────────────────── */
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('X-Powered-By', 'Anaconda-API/2.1.0');
}

/* ── Logger ──────────────────────────────────────────────────────── */
function log(req, statusCode) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] ${req.method.padEnd(7)} ${req.url.padEnd(45)} → ${statusCode}`);
}

/* ── Routeur principal ───────────────────────────────────────────── */
async function router(req, res) {
  setCORS(res);

  // Preflight CORS
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  // Parse path (sans query string)
  req.parsedPath = req.url.split('?')[0].replace(/\/$/, '') || '/';

  // Intercepter les erreurs JSON
  req.on('error', () => serverError(res));

  try {
    let handled = null;

    /* ── Routes publiques ──────────────────────────────────── */
    if (req.parsedPath.startsWith('/api/auth')) {
      handled = await authRoutes(req, res, db, gateway, auth);
    }

    else if (req.parsedPath.startsWith('/api/operators')) {
      handled = await operatorRoutes(req, res, db, gateway);
    }

    /* ── Health check ──────────────────────────────────────── */
    else if (req.parsedPath === '/api/health' || req.parsedPath === '/') {
      const { ok } = require('./utils/http');
      const stats  = db.userStats('usr-001');
      return ok(res, {
        status:    'OK',
        service:   'Anaconda API',
        version:   '2.1.0',
        operators: ['MTN MoMo', 'Orange Money', 'Moov Money', 'Wave'],
        uptime:    process.uptime(),
        timestamp: new Date().toISOString(),
      });
    }

    /* ── Routes protégées ──────────────────────────────────── */
    else if (req.parsedPath.startsWith('/api/wallets')) {
      handled = await walletRoutes(req, res, db, gateway, auth);
    }

    else if (req.parsedPath.startsWith('/api/transfers')) {
      handled = await transferRoutes(req, res, db, gateway, auth);
    }

    else if (req.parsedPath.startsWith('/api/user')) {
      handled = await userRoutes(req, res, db, gateway, auth);
    }

    /* ── Documentation API ─────────────────────────────────── */
    else if (req.parsedPath === '/api') {
      const { ok } = require('./utils/http');
      return ok(res, {
        name:    'Anaconda API',
        version: '2.1.0',
        endpoints: {
          auth: {
            'POST /api/auth/register':    'Créer un compte',
            'POST /api/auth/login':       'Se connecter (retourne token)',
            'POST /api/auth/logout':      'Se déconnecter [auth]',
            'POST /api/auth/otp/send':    'Envoyer OTP SMS',
            'POST /api/auth/otp/verify':  'Vérifier OTP',
            'POST /api/auth/pin/change':  'Changer le PIN [auth]',
          },
          user: {
            'GET  /api/user/profile':          'Profil utilisateur [auth]',
            'PATCH /api/user/profile':         'Modifier le profil [auth]',
            'GET  /api/user/stats':            'Statistiques du mois [auth]',
            'GET  /api/user/devices':          'Appareils connectés [auth]',
            'DELETE /api/user/devices/:id':    'Retirer un appareil [auth]',
            'DELETE /api/user/devices':        'Déconnecter tous [auth]',
            'POST /api/user/phone/change':     'Changer de numéro [auth]',
          },
          wallets: {
            'GET  /api/wallets':               'Lister mes portefeuilles [auth]',
            'POST /api/wallets':               'Ajouter un portefeuille [auth]',
            'GET  /api/wallets/:id':           'Détail portefeuille [auth]',
            'DELETE /api/wallets/:id':         'Supprimer portefeuille [auth]',
            'GET  /api/wallets/:id/balance':   'Vérifier solde réseau [auth]',
            'GET  /api/wallets/:id/plafond':   'Voir les plafonds [auth]',
            'POST /api/wallets/verify-phone':  'Vérifier numéro opérateur [auth]',
          },
          transfers: {
            'POST /api/transfers/quote':       'Simuler un transfert (frais) [auth]',
            'POST /api/transfers':             'Exécuter un transfert [auth]',
            'GET  /api/transfers':             'Historique [auth] ?type=&operator=&limit=&offset=',
            'GET  /api/transfers/:id':         'Détail transaction [auth]',
            'GET  /api/transfers/:id/status':  'Statut en temps réel [auth]',
          },
          operators: {
            'GET  /api/operators':              'Liste opérateurs supportés',
            'GET  /api/operators/:code':        'Détail opérateur',
            'GET  /api/operators/:code/fee':    'Calculer frais ?amount=&toOperator=',
            'POST /api/operators/:code/verify': 'Vérifier numéro',
          },
        },
      });
    }

    if (handled === null) notFound(res);
  } catch (e) {
    console.error('[ERROR]', e);
    serverError(res, e.message);
  }
}

/* ── Création du serveur ─────────────────────────────────────────── */
const server = http.createServer((req, res) => {
  const origEnd    = res.end.bind(res);
  const origWrite  = res.writeHead.bind(res);
  let   statusCode = 200;

  res.writeHead = (code, headers) => { statusCode = code; return origWrite(code, headers); };
  res.end       = (...args) => {
    log(req, statusCode);
    return origEnd(...args);
  };

  router(req, res);
});

server.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║          🐍  ANACONDA API  v2.1.0               ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║  ✅  Serveur démarré sur http://localhost:${PORT}   ║`);
  console.log('║  📡  Opérateurs : MTN · Orange · Moov · Wave    ║');
  console.log('║  🗄️   Base de données : anaconda.json            ║');
  console.log('║  📖  Documentation : http://localhost:3000/api  ║');
  console.log('╚══════════════════════════════════════════════════╝\n');
  console.log('  Compte démo : phone=0712345656 · PIN=1234\n');
});

server.on('error', e => { console.error('[SERVER ERROR]', e.message); process.exit(1); });

module.exports = server;
