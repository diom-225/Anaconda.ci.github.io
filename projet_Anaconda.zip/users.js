'use strict';
/**
 * ANACONDA API — Routes : Utilisateur
 * GET  /api/user/profile
 * PATCH /api/user/profile
 * GET  /api/user/stats
 * GET  /api/user/devices
 * DELETE /api/user/devices/:id
 * POST /api/user/phone/change
 */

const { ok, err, notFound, readBody } = require('../utils/http');

async function userRoutes(req, res, db, gateway, auth) {
  const method    = req.method;
  const path      = req.parsedPath;
  const pathParts = path.split('/').filter(Boolean);

  return new Promise(resolve => {
    auth(req, res, async () => {
      const userId = req.user.id;

      /* GET /api/user/profile ─────────────────────────────── */
      if (method === 'GET' && path === '/api/user/profile') {
        const user = db.findUser(userId);
        const { pinHash, ...safeUser } = user;
        return resolve(ok(res, safeUser));
      }

      /* PATCH /api/user/profile ───────────────────────────── */
      if (method === 'PATCH' && path === '/api/user/profile') {
        const body = await readBody(req);
        const allowed = ['name', 'email'];
        const patch   = {};
        allowed.forEach(k => { if (body[k] !== undefined) patch[k] = body[k]; });
        if (!Object.keys(patch).length) return resolve(err(res, 'Aucun champ modifiable fourni'));
        const updated = db.updateUser(userId, patch);
        const { pinHash, ...safeUser } = updated;
        return resolve(ok(res, { user: safeUser, message: 'Profil mis à jour' }));
      }

      /* GET /api/user/stats ───────────────────────────────── */
      if (method === 'GET' && path === '/api/user/stats') {
        const stats = db.userStats(userId);
        const now   = new Date();
        const label = now.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
        return resolve(ok(res, { ...stats, period: label }));
      }

      /* GET /api/user/devices ─────────────────────────────── */
      if (method === 'GET' && path === '/api/user/devices') {
        const user = db.findUser(userId);
        return resolve(ok(res, { devices: user.devices || [], count: (user.devices || []).length }));
      }

      /* DELETE /api/user/devices/:id ─────────────────────── */
      if (method === 'DELETE' && pathParts[1]==='user' && pathParts[2]==='devices' && pathParts[3]) {
        const devId = pathParts[3];
        const user  = db.findUser(userId);
        const dev   = (user.devices||[]).find(d => d.id === devId);
        if (!dev) return resolve(notFound(res));
        if (dev.current) return resolve(err(res, 'Impossible de retirer l\'appareil courant'));
        db.updateUser(userId, { devices: (user.devices||[]).filter(d => d.id !== devId) });
        return resolve(ok(res, { message: 'Appareil déconnecté' }));
      }

      /* DELETE /api/user/devices (tous sauf courant) ──────── */
      if (method === 'DELETE' && path === '/api/user/devices') {
        const user = db.findUser(userId);
        db.updateUser(userId, { devices: (user.devices||[]).filter(d => d.current) });
        return resolve(ok(res, { message: 'Tous les autres appareils déconnectés' }));
      }

      /* POST /api/user/phone/change ───────────────────────── */
      if (method === 'POST' && path === '/api/user/phone/change') {
        const body = await readBody(req);
        const { newPhone, otpCode, pin } = body;
        if (!newPhone || !otpCode || !pin) return resolve(err(res, 'Champs requis : newPhone, otpCode, pin'));

        const { hashPin } = require('../db/database');
        if (req.user.pinHash !== hashPin(pin)) return resolve(err(res, 'Code PIN incorrect', 401, 'WRONG_PIN'));

        const valid = db.verifyOTP(newPhone, otpCode);
        if (!valid) return resolve(err(res, 'Code OTP invalide ou expiré', 400, 'INVALID_OTP'));

        if (db.findUserByPhone(newPhone)) return resolve(err(res, 'Ce numéro est déjà utilisé', 409));

        db.updateUser(userId, { phone: newPhone, phoneChangedAt: new Date().toISOString() });
        return resolve(ok(res, { message: 'Numéro de téléphone mis à jour', newPhone }));
      }

      resolve(null);
    });
  });
}

module.exports = userRoutes;
