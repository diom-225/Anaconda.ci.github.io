'use strict';
/**
 * ANACONDA API — Routes : Authentification
 * POST /api/auth/register
 * POST /api/auth/login
 * POST /api/auth/logout
 * POST /api/auth/otp/send
 * POST /api/auth/otp/verify
 * POST /api/auth/pin/change
 */

const { ok, created, err, unauthorized, readBody } = require('../utils/http');
const { signToken } = require('../utils/jwt');
const { hashPin }   = require('../db/database');

async function authRoutes(req, res, db, gateway, auth) {
  const method = req.method;
  const path   = req.parsedPath;

  /* ── POST /api/auth/register ─────────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/register') {
    const body = await readBody(req);
    const { name, phone, pin } = body;

    if (!name || !phone || !pin)        return err(res, 'Champs requis : name, phone, pin');
    if (!/^\d{4}$/.test(pin))          return err(res, 'Le PIN doit contenir exactement 4 chiffres');
    if (db.findUserByPhone(phone))      return err(res, 'Ce numéro est déjà enregistré', 409, 'DUPLICATE_PHONE');

    const user = db.createUser({ name, phone, pinHash: hashPin(pin), kycStatus: 'pending' });
    const token  = signToken({ userId: user.id });
    db.createSession(user.id, token, new Date(Date.now() + 24*3600*1000).toISOString());

    return created(res, {
      user:    { id: user.id, name: user.name, phone: user.phone, kycStatus: user.kycStatus },
      token,
      message: 'Compte créé avec succès',
    });
  }

  /* ── POST /api/auth/login ────────────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/login') {
    const body = await readBody(req);
    const { phone, pin } = body;

    if (!phone || !pin) return err(res, 'Champs requis : phone, pin');

    const user = db.findUserByPhone(phone);
    if (!user)                          return unauthorized(res);
    if (user.pinHash !== hashPin(pin))  return err(res, 'Code PIN incorrect', 401, 'WRONG_PIN');

    const token = signToken({ userId: user.id });
    db.createSession(user.id, token, new Date(Date.now() + 24*3600*1000).toISOString());

    // Mettre à jour lastLogin
    db.updateUser(user.id, { lastLogin: new Date().toISOString() });

    return ok(res, {
      user:  { id: user.id, name: user.name, phone: user.phone, kycStatus: user.kycStatus },
      token,
      expiresIn: 86400,
    });
  }

  /* ── POST /api/auth/logout ───────────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/logout') {
    auth(req, res, () => {
      db.deleteSession(req.token);
      return ok(res, { message: 'Déconnexion réussie' });
    });
    return;
  }

  /* ── POST /api/auth/otp/send ─────────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/otp/send') {
    const body = await readBody(req);
    const { phone } = body;
    if (!phone) return err(res, 'Champ requis : phone');

    const result = await gateway.sendOTP(phone);
    const code   = result.code;
    db.createOTP(phone, code);

    return ok(res, { message: `Code OTP envoyé au ${phone}`, expiresIn: 300, ...(process.env.NODE_ENV !== 'production' ? { demoCode: code } : {}) });
  }

  /* ── POST /api/auth/otp/verify ───────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/otp/verify') {
    const body = await readBody(req);
    const { phone, code } = body;
    if (!phone || !code) return err(res, 'Champs requis : phone, code');

    const valid = db.verifyOTP(phone, code);
    if (!valid) return err(res, 'Code OTP invalide ou expiré', 400, 'INVALID_OTP');

    return ok(res, { verified: true, message: 'Numéro vérifié avec succès' });
  }

  /* ── POST /api/auth/pin/change ───────────────────────────────── */
  if (method === 'POST' && path === '/api/auth/pin/change') {
    auth(req, res, async () => {
      const body = await readBody(req);
      const { currentPin, newPin } = body;
      if (!currentPin || !newPin) return err(res, 'Champs requis : currentPin, newPin');
      if (!/^\d{4}$/.test(newPin)) return err(res, 'Le nouveau PIN doit contenir 4 chiffres');
      if (req.user.pinHash !== hashPin(currentPin)) return err(res, 'Code PIN actuel incorrect', 401, 'WRONG_PIN');

      db.updateUser(req.user.id, { pinHash: hashPin(newPin) });
      db.deleteSession(req.token); // invalide la session en cours → reconnexion requise

      return ok(res, { message: 'Code PIN modifié — veuillez vous reconnecter' });
    });
    return;
  }

  return null; // route non trouvée
}

module.exports = authRoutes;
