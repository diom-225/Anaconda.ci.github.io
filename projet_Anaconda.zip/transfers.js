'use strict';
/**
 * ANACONDA API — Routes : Transferts
 * POST /api/transfers/quote          → Calculer frais avant transfert
 * POST /api/transfers                → Exécuter un transfert
 * GET  /api/transfers                → Historique paginé
 * GET  /api/transfers/:id            → Détail d'un transfert
 * GET  /api/transfers/:id/status     → Statut en temps réel
 */

const { ok, created, err, notFound, readBody, parseQuery } = require('../utils/http');
const { uid } = require('../db/database');
const crypto = require('crypto');

function genRef() {
  return 'ANA' + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString('hex').toUpperCase();
}

async function transferRoutes(req, res, db, gateway, auth) {
  const method    = req.method;
  const path      = req.parsedPath;
  const pathParts = path.split('/').filter(Boolean);

  return new Promise(resolve => {
    auth(req, res, async () => {
      const userId = req.user.id;

      /* ── POST /api/transfers/quote ─────────────────────────── */
      if (method === 'POST' && path === '/api/transfers/quote') {
        const body = await readBody(req);
        const { fromOperator, toOperator, amount } = body;

        if (!fromOperator || !toOperator || !amount) return resolve(err(res, 'Champs requis : fromOperator, toOperator, amount'));

        let fromOp, toOp;
        try { fromOp = gateway.getOperator(fromOperator); toOp = gateway.getOperator(toOperator); }
        catch (e) { return resolve(err(res, e.message)); }

        if (fromOperator === toOperator) return resolve(err(res, 'Source et destination identiques'));
        if (amount < fromOp.minAmount)   return resolve(err(res, `Montant minimum : ${fromOp.minAmount} FCFA`));
        if (amount > fromOp.maxAmount)   return resolve(err(res, `Montant maximum : ${fromOp.maxAmount} FCFA`));

        const { fee, feeRate, freeReason } = gateway.computeFee(fromOperator, toOperator, amount);
        const walletFrom = db.findWalletByOp(userId, fromOperator);

        return resolve(ok(res, {
          fromOperator: { code: fromOperator, name: fromOp.name },
          toOperator:   { code: toOperator,   name: toOp.name   },
          amount,
          fee,
          feeRate,
          freeReason,
          totalDebit:   amount + fee,
          amountCredit: amount,
          currency:     'XOF',
          delay:        toOp.delay,
          delayLabel:   toOp.delay === 0 ? 'Instantané' : `~${Math.ceil(toOp.delay/60000)} min`,
          balanceSufficient: walletFrom ? walletFrom.balance >= (amount + fee) : false,
          validUntil:   new Date(Date.now() + 60000).toISOString(), // devis valide 1 min
        }));
      }

      /* ── POST /api/transfers ──────────────────────────────── */
      if (method === 'POST' && path === '/api/transfers') {
        const body = await readBody(req);
        const { fromOperator, toOperator, amount, pin } = body;

        // Validation entrées
        if (!fromOperator || !toOperator || !amount || !pin)
          return resolve(err(res, 'Champs requis : fromOperator, toOperator, amount, pin'));

        // Vérifier PIN
        const { hashPin } = require('../db/database');
        if (req.user.pinHash !== hashPin(pin))
          return resolve(err(res, 'Code PIN incorrect', 401, 'WRONG_PIN'));

        if (fromOperator === toOperator)
          return resolve(err(res, 'Source et destination identiques'));

        // Récupérer portefeuilles
        const walletFrom = db.findWalletByOp(userId, fromOperator);
        const walletTo   = db.findWalletByOp(userId, toOperator);
        if (!walletFrom) return resolve(err(res, `Portefeuille ${fromOperator.toUpperCase()} non lié`, 404, 'WALLET_NOT_FOUND'));
        if (!walletTo)   return resolve(err(res, `Portefeuille ${toOperator.toUpperCase()} non lié`,   404, 'WALLET_NOT_FOUND'));

        // Vérifier opérateurs
        let fromOp, toOp;
        try { fromOp = gateway.getOperator(fromOperator); toOp = gateway.getOperator(toOperator); }
        catch (e) { return resolve(err(res, e.message)); }

        if (amount < fromOp.minAmount) return resolve(err(res, `Montant minimum : ${fromOp.minAmount} FCFA`));
        if (amount > fromOp.maxAmount) return resolve(err(res, `Montant maximum : ${fromOp.maxAmount} FCFA`));

        const { fee } = gateway.computeFee(fromOperator, toOperator, amount);
        const totalDebit = amount + fee;

        if (walletFrom.balance < totalDebit)
          return resolve(err(res, `Solde insuffisant (${walletFrom.balance} FCFA disponibles, ${totalDebit} FCFA requis)`, 400, 'INSUFFICIENT_BALANCE'));

        // Référence unique
        const ref = genRef();

        // Créer la transaction en état "processing"
        const tx = db.createTx({
          userId,
          type:         'debit',
          operator:     fromOperator,
          toOperator,
          amount,
          fee,
          totalDebit,
          ref,
          label:        `${fromOp.name} → ${toOp.name}`,
          status:       'processing',
          fromPhone:    walletFrom.phone,
          toPhone:      walletTo.phone,
        });

        // Appel passerelle opérateurs
        let gatewayResult;
        try {
          gatewayResult = await gateway.transfer({
            fromOperator, fromPhone: walletFrom.phone,
            toOperator,   toPhone:   walletTo.phone,
            amount, ref,
          });
        } catch (e) {
          db.updateTx(tx.id, { status: 'failed', failureReason: e.message, updatedAt: new Date().toISOString() });
          return resolve(err(res, `Échec réseau : ${e.message}`, 502, 'GATEWAY_ERROR'));
        }

        if (!gatewayResult.success) {
          db.updateTx(tx.id, { status: 'failed', failureReason: gatewayResult.error, updatedAt: new Date().toISOString() });
          return resolve(err(res, gatewayResult.error, 502, 'GATEWAY_ERROR'));
        }

        // Mettre à jour les soldes
        db.updateWallet(walletFrom.id, {
          balance:     walletFrom.balance - totalDebit,
          monthlyOut:  (walletFrom.monthlyOut || 0) + totalDebit,
          monthlyUsed: (walletFrom.monthlyUsed || 0) + totalDebit,
        });
        db.updateWallet(walletTo.id, {
          balance:    walletTo.balance + amount,
          monthlyIn:  (walletTo.monthlyIn || 0) + amount,
        });

        // Enregistrer aussi la transaction de crédit côté destination
        db.createTx({
          userId,
          type:       'credit',
          operator:   toOperator,
          fromOperator,
          amount,
          fee:        0,
          ref:        ref + '-CR',
          label:      `Crédit reçu (${fromOp.name})`,
          status:     'completed',
          fromPhone:  walletFrom.phone,
          toPhone:    walletTo.phone,
        });

        // Finaliser la transaction débit
        db.updateTx(tx.id, {
          status:      'completed',
          debitRef:    gatewayResult.debitRef,
          creditRef:   gatewayResult.creditRef,
          updatedAt:   new Date().toISOString(),
          completedAt: new Date().toISOString(),
          networkLatencyMs: gatewayResult.networkLatencyMs,
        });

        return resolve(ok(res, {
          transactionId:  tx.id,
          ref,
          status:         'completed',
          fromOperator:   { code: fromOperator, name: fromOp.name, phone: walletFrom.phone },
          toOperator:     { code: toOperator,   name: toOp.name,   phone: walletTo.phone   },
          amount,
          fee,
          totalDebit,
          amountCredit:   amount,
          newBalanceFrom: walletFrom.balance - totalDebit,
          newBalanceTo:   walletTo.balance   + amount,
          debitRef:       gatewayResult.debitRef,
          creditRef:      gatewayResult.creditRef,
          completedAt:    new Date().toISOString(),
          networkLatencyMs: gatewayResult.networkLatencyMs,
        }));
      }

      /* ── GET /api/transfers ───────────────────────────────── */
      if (method === 'GET' && path === '/api/transfers') {
        const q = parseQuery(req);
        const { type, operator, limit = '20', offset = '0' } = q;
        const result = db.userTransactions(userId, { type, operator, limit: parseInt(limit), offset: parseInt(offset) });
        return resolve(ok(res, result));
      }

      /* ── Routes avec :id ──────────────────────────────────── */
      if (pathParts.length >= 3 && pathParts[1] === 'transfers') {
        const txId = pathParts[2];
        const tx   = db.findTx(txId);
        if (!tx || tx.userId !== userId) return resolve(notFound(res));

        /* GET /api/transfers/:id ─────────────────────────── */
        if (method === 'GET' && pathParts.length === 3) {
          return resolve(ok(res, tx));
        }

        /* GET /api/transfers/:id/status ──────────────────── */
        if (method === 'GET' && pathParts[3] === 'status') {
          // Simule la mise à jour d'un transfert "pending"
          if (tx.status === 'pending' && (Date.now() - new Date(tx.createdAt).getTime()) > 300000) {
            db.updateTx(txId, { status: 'completed', completedAt: new Date().toISOString() });
          }
          const updated = db.findTx(txId);
          return resolve(ok(res, {
            transactionId: updated.id,
            ref:           updated.ref,
            status:        updated.status,
            createdAt:     updated.createdAt,
            updatedAt:     updated.updatedAt || updated.createdAt,
            completedAt:   updated.completedAt || null,
          }));
        }
      }

      resolve(null);
    });
  });
}

module.exports = transferRoutes;
